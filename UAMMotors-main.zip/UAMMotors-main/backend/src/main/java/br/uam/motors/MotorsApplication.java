package br.uam.motors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MotorsApplication {
	public static void main(String[] args) {
		SpringApplication.run(MotorsApplication.class, args);
	}
}