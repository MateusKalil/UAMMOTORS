package br.uam.motors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MotorsApplicationTests {

	@Test
	void contextLoads() {
	}

}
