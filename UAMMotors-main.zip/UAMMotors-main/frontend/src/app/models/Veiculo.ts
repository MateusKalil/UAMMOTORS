export class Veiculo{
    id?: number = 0;
    marca: string = '';
    modelo: string = '';
    ano: number = 0;
    preco: number = 0;
    cor: string = '';
    estoque: String = 'estoque';
    imagem: string = '';
}

