export class Funcionario{
    id?: number;
    nome: string = '';
    sobrenome: string = '';
    usuario: string = '';
    telefone: string = '';
    senha: string = '';
}